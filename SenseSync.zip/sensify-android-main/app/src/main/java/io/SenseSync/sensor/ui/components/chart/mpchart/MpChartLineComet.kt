package io.SenseSync.sensor.ui.components.chart.mpchart

import io.SenseSync.sensor.ui.components.chart.mpchart.base.MpChartLineView

/**
 * Created by Niraj on 30-09-2022.
 */
class MpChartLineComet() : MpChartLineView(1) {



}