package io.sensify.sensor.ui

import android.content.Context
import android.hardware.SensorManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.lifecycleScope
import com.google.accompanist.pager.ExperimentalPagerApi
import io.SenseSync.sensor.domains.sensors.packets.SensorPacketsProvider
import io.SenseSync.sensor.domains.sensors.provider.SensorsProvider
import io.SenseSync.sensor.ui.navigation.NavGraphApp
import io.SenseSync.sensor.ui.resource.themes.SensifyM3Theme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.coroutines.suspendCoroutine

class MainActivity : ComponentActivity() {

    @OptIn(ExperimentalPagerApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
//        throw NumberFormatException("Test Crash") // Force a crash
        lifecycleScope.launch {
            SensorsProvider.getInstance().setSensorManager(sensorManager)
            SensorPacketsProvider.getInstance().setSensorManager(sensorManager)
            setContent {
                SensifyM3Theme {
                    // A surface container using the 'background' color from the theme
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {


                        NavGraphApp()

                    }
                }
            }
        }


    }


    override fun onDestroy() {
        super.onDestroy()
//        scope
//        coroutineScope {
            SensorsProvider.getInstance().clearAll();


            SensorPacketsProvider.getInstance().clearAll();
//        }
        lifecycleScope.launch {

        }
        CoroutineScope(Job())


        //setSensorManager(sensorManager)
    }

    suspend fun dsds(){
        suspendCoroutine<Unit> {  }
    }

}
