package io.SenseSync.sensor.ui.resource.values


object JlResStyles {

}