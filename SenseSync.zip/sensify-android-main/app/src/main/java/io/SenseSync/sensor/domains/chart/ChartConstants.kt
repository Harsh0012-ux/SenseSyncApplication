package io.SenseSync.sensor.domains.chart

object ChartConstants {


    const val DIRECTION_START_END = 1
    const val DIRECTION_END_START = 2


    const val REFRESH_RATE = 20




}