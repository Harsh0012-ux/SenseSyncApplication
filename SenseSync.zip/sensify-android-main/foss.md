
# github build CD 
- https://proandroiddev.com/how-to-securely-build-and-sign-your-android-app-with-github-actions-ad5323452ce
- https://www.kodeco.com/19407406-continuous-delivery-for-android-using-github-actions

# release on playstore
- https://www.freecodecamp.org/news/use-github-actions-to-automate-android-development/

# action
- https://github.com/marketplace/actions/sign-android-release

# CI
- https://www.kodeco.com/10562143-continuous-integration-for-android?__hstc=149040233.9779d8d4ec7ab1f21c47af3c46954b7c.1677797844545.1677797844545.1677797844545.1&__hssc=149040233.1.1677797844545&__hsfp=1483251232

# encode -decode
- https://stackoverflow.com/questions/42592518/encode-decode-exe-into-base64

# gradle not allowed
- git update-index --chmod=+x gradlew
- https://stackoverflow.com/questions/17668265/gradlew-permission-denied

# google services json
- https://stackoverflow.com/questions/70568653/google-services-json-file-for-github-actions

# signing
- https://github.com/r0adkll/sign-android-release/issues/34

# openssl
- https://adamtheautomator.com/openssl-windows-10/

# gradle
- http://tools.android.com/tech-docs/new-build-system/user-guide#TOC-Product-Flavor-Configuration